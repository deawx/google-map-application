# google-map-application
Simple application to read a json file and draw google maps and charts to represent its data.
This application can be seen in action at http://demo.techinceptum.com/farmers
